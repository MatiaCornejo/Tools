__author__ = 'Andrew Dunham <andrew@du.nham.ca>'
__version__ = '0.0.1'
